package testapp

import (
	"testing"
)

func TestRegularLoop(t *testing.T) {
	RegularLoop()
}

func BenchmarkRegularLoop(t *testing.B) {
	RegularLoop()
}

func TestBigLoop(t *testing.T) {
	BigLoop()
}

func BenchmarkBiggerLoop(t *testing.B) {
	BiggerLoop()
}
