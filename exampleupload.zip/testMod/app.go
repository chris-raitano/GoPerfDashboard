package testapp

func SmallLoop() {
	for i := 0; i < 100; i++ {
	}
}

func RegularLoop() {
	for i := 0; i < 1000; i++ {
	}
}

func BigLoop() {
	for i := 0; i < 10000; i++ {
	}
}

func BiggerLoop() {
	for i := 0; i < 100000; i++ {
	}
}
